const header = document.querySelector('.site-header');
const navToggle = document.querySelector('.nav-toggle');
const navLinks = document.querySelector('[data-nav-links]');
const year = document.querySelector('[data-year]');

if (year) year.textContent = new Date().getFullYear();

if (navToggle && header && navLinks) {
  navToggle.addEventListener('click', () => {
    const open = header.classList.toggle('nav-open');
    navToggle.setAttribute('aria-expanded', String(open));
    navToggle.setAttribute('aria-label', open ? 'Close navigation menu' : 'Open navigation menu');
  });

  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      header.classList.remove('nav-open');
      navToggle.setAttribute('aria-expanded', 'false');
      navToggle.setAttribute('aria-label', 'Open navigation menu');
    });
  });
}

const revealItems = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window) {
  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });
  revealItems.forEach(item => revealObserver.observe(item));
} else {
  revealItems.forEach(item => item.classList.add('is-visible'));
}

const sections = document.querySelectorAll('main section[id]');
const menuLinks = document.querySelectorAll('.nav-links a[href^="#"]');
if ('IntersectionObserver' in window && sections.length) {
  const activeObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const id = entry.target.getAttribute('id');
      menuLinks.forEach(link => link.classList.toggle('active', link.getAttribute('href') === `#${id}`));
    });
  }, { rootMargin: '-35% 0px -55% 0px' });
  sections.forEach(section => activeObserver.observe(section));
}

const modal = document.querySelector('[data-modal]');
const modalImage = document.querySelector('[data-modal-image]');
const modalTitle = document.querySelector('[data-modal-title]');
const closeModalButton = document.querySelector('[data-modal-close]');
const resultCards = document.querySelectorAll('.result-card');
let lastFocusedCard = null;

function openModal(card) {
  if (!modal || !modalImage || !modalTitle) return;
  lastFocusedCard = card;
  const fullImage = card.getAttribute('data-full');
  const title = card.getAttribute('data-title') || 'SEO result screenshot';
  modalImage.src = fullImage;
  modalImage.alt = title;
  modalTitle.textContent = title;
  modal.classList.add('is-open');
  modal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('modal-open');
  if (closeModalButton) closeModalButton.focus();
}

function closeModal() {
  if (!modal || !modalImage) return;
  modal.classList.remove('is-open');
  modal.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('modal-open');
  modalImage.src = '';
  if (lastFocusedCard) lastFocusedCard.focus();
}

resultCards.forEach(card => card.addEventListener('click', () => openModal(card)));
if (closeModalButton) closeModalButton.addEventListener('click', closeModal);
if (modal) {
  modal.addEventListener('click', event => { if (event.target === modal) closeModal(); });
}
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });
